
## Summary (Summarize the bug encountered concisely)

Create New Project - page has a typing error "black" instead of "blank"

## Steps to reproduce     

Navigate to [Main_Page_URL](https://gitlab.com/)
Click on Create New
Click on New Project / Repository
You will be on page https://gitlab.com/projects/new

## What is the current bug behavior?

in HTML the "Create blank project" is misspelled, it is now "Create black project"  

## What is the expected correct behavior?

"Black" should be changed to "blank"
     
## Relevant logs and/or screenshots

Please see the screenshot attached
![Image info](../Image/Bug_Project_create_blank.png)


## Possible fixes

Correct spelling to "blank" in the following div

<div class="gl-pl-4"><h3 class="gl-font-size-h2 gl-reset-color">
            Create blank project
          </h3> <p class="gl-text-gray-900">
            Create a blank project to store your files, plan your work, and collaborate on code, among other things.
          </p></div>

## Whom do you report/ Assign To/ Tags

/label ~bug ~reproduced ~needs-investigation 
      /cc @project-manager 
      /assign @qa-tester

## Priority
Minor 
This is a spelling error and does not affect the functionality of the webapp
      
