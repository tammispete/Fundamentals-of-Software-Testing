
# TODO

> Please use the below questions as guidelines to help you think and plan your Learning Reflection Report

## 1. How was your experience testing the given Webapp?
- 
This testing process was very informative, it gave a good view on how manual testing would be created. It also showed, that tester should have knowledge on the webapp before even starting to plan testing, as the functionality of the site should be known beforehand. For example what should happen when you press accept, create, etc.

## 2. How did you write or manage your test case? Describe the process.
- 
I used the example given in the Login Page test case. After that I did the other testcases by starting with positive test cases, actually doing the test and then moving to negatives. This way I had an idea of what is going to happen. As this webapp was not very familiar to me, I had to do it step by step and actually see what happens. I would imagine that in a real life testing I would have had documentation or other knowledge, on how the webapp should have functioned, but this way I also knew, that the testing would give a positive outcome.

I tried to figure out as many variables as possible before writing test cases, but had to add several during creation of test cases.

One issue was the word "click", I used it as it was also mentioned in the videos. But this took a little while to think, how should I write this step and would it be easy for anyone using these steps to recreate.


## 3. Do you recommend any other tools or styles for Test case management. 
 -
I have no experience in other tools or styles. This could be ofcourse done in Excel, like in the videos shared in this course.
This visual studio - version is very good in my opinion and if used like this, the developers would also understand the structure very easily.

## 4. Which IDE (Visual Code or Atom or else) have you used to edit files?
- 
I used Visual Studio Code. The only issue is, that you cannot attach screenshots directly on to the files, it needs to be a separate file. I would presume Excel could have this feature. Of course there are actual ticket-apps that have this capability as well.

     
## 5. Did you find any trouble? how did you solve the trouble?
-
There were issues, for example I did not know what the next step for a postive or negative test case should be. This way I needed to see before writing it in the test case.
For example: I did not know what happens if I try to duplicate a project name, so I needed to do that and then I could write a test case that what the error text is. 
Verify that Message shows "	The form contains the following errors:    Project namespace name has already been taken    Name has already been taken    Path has already been taken"	 

## 6. Did you find any trouble using Github? have you used Github before? where?
-
Github is familiar with me from Javascript courses, but it is still a bit unfamiliar and I am not 100% comftorable with it.
      

## 7. If in the future if you need to automate these test cases, which framework or language will you use? and describe why (Robot Framework, Cypress, Selenium, or any other )
- 
I have not been familiarized with any automation tools yet. I would still estimate, that I would recommend Robot Framework, as it is commonly used in Finland, most likely due to the fact that it used to be an internal component in Nokia before going opensource. Open source app means that it is free to use and has a large community to help with issues.


## 8. Kindly search the term `Tester` `Automation Tester` glassdoor and LinkedIn or any other job search website. Currently, list the skills and competencies that are most in-demand in software testing
- 
 Experience in automation tools
 Python
 Experience in automation continous integration / agile / DevOps
 Adaptavist/Zephyr, Robot Framework, Selenium, Zed Attack Proxy, Browser stack, JMeter
 Experience in testing practices: TDD, BDD, Data-Driven testing



## 9. **Let's assume** that if you are going to continue with the career in Software Testing, which technical and soft skills do you need to fill up the blank in your resume?
- 
I believe in my soft skills, this is my strong suit in the field of testing. I am very diplomatic and get along with people. This means, that I would be good with information and would be easy to approach even if you are the developer and I am making bug reports. I would also be a good asset in all meetings requiered.

The weaknessess:
I have basic theory of testing now, but no idea how it is actually done, so no experience.
I need to learn Python as well.
I have not done any automation testing and not used any framework like Robot Framework.


## 10. Write short Learning Reflection and  Free words Do you think that project helped in putting theoretical knowledge into practice? Describe? (is there anything else that you would like to share with us concerning the current study module). e.g. regarding the quality of content and your learning (or) improvement ideas? 
-
The theory was much more difficult then I would have imagined, as I learn most by doing. Sometimes I noticed when reading for example about Black-Box and White-Box testing techniques, that I did not understand anything and had to repeat chapters. The video-material helped alot though and made me understand much better. I first read the chapters and then watched the videos. Other then that, I feel that this gives a good general idea of testing and testing methods.

Maybe, as we are not going to get the certificate exam anyway, there could have been more actual projects like this instead of the quizzes. For example, teacher creates a simple webapp ( or take a app that has been returned for example in some other code-course, I am sure there are good examples there to re-create) and then ask the students to do a black-box/white-box technique testing on it. Then they would have to re-read for example the blackbox-technique steps and create these test plans. There could be for example a number-based app so we could start thinking of min max values etc. This would simulate the "real world" challenges of testing in my opinion.  Or then have a company use students as testers in some project that can handle amateur testing and learn by doing that way, or even Laurea internal website testing? These ideas of course would be very time and recourse - consuming for the teachers, I understand that it might be an issue of those.






 





